package com.example.myapplication

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity

class FormularioVehiculoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formulario_vehiculo)

        val colores = arrayOf("Blanco", "Negro", "Azul")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, colores)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        findViewById<Spinner>(R.id.spinnerColor).adapter = adapter

        val btnGuardar = findViewById<Button>(R.id.btnGuardarVehiculo)
        btnGuardar.setOnClickListener {
            // Aquí obtienes los datos del formulario
            val placa = findViewById<EditText>(R.id.etPlaca).text.toString()
            val marca = findViewById<EditText>(R.id.etMarca).text.toString()
            val fechaFabricacion = findViewById<EditText>(R.id.etFechaFabricacion).text.toString()
            val color = findViewById<Spinner>(R.id.spinnerColor).selectedItem.toString()
            val costo = findViewById<EditText>(R.id.etCosto).text.toString().toDouble()
            val activo = findViewById<CheckBox>(R.id.cbActivo).isChecked

            // Crear el nuevo vehículo
            val nuevoVehiculo = Vehiculo(R.drawable.ic_vehicle, placa, marca, fechaFabricacion, color, costo, activo)

            // Retornar el nuevo vehículo a la actividad principal
            val intent = Intent()
            intent.putExtra("vehiculo", nuevoVehiculo)
            setResult(Activity.RESULT_OK, intent)
            finish()
        }
    }
}