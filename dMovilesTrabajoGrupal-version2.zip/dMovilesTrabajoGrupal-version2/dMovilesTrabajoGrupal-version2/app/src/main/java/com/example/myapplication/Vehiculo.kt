package com.example.myapplication

import java.io.Serializable

data class Vehiculo(
    val imageResource: Int, // Aquí almacenarás la referencia al recurso de la imagen
    val placa: String,
    val marca: String,
    val fechaFabricacion: String,
    val color: String,
    val costo: Double,
    val activo: Boolean
) : Serializable
