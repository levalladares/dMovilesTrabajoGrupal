package com.example.myapplication

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView

class VehiculoAdapter(context: Context,
    private val vehiculos: List<Vehiculo>
) : ArrayAdapter<Vehiculo>(context, 0, vehiculos){

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_vehiculo, parent, false)
        val vehiculo = vehiculos[position]

        // Establecer la imagen
        val imagenVehiculo = view.findViewById<ImageView>(R.id.imagenVehiculo)
        val tvPlaca = view.findViewById<TextView>(R.id.etPlaca)
        val tvMarca = view.findViewById<TextView>(R.id.etMarca)
        imagenVehiculo.setImageResource(vehiculo.imageResource)

        // Establecer las características
        view.findViewById<TextView>(R.id.placa).text = vehiculo.placa
        view.findViewById<TextView>(R.id.marca).text = vehiculo.marca
        view.findViewById<TextView>(R.id.fechaFabricacion).text = vehiculo.fechaFabricacion
        view.findViewById<TextView>(R.id.color).text = vehiculo.color
        view.findViewById<TextView>(R.id.costo).text = vehiculo.costo.toString()
        view.findViewById<TextView>(R.id.activo).text = if (vehiculo.activo) "Sí" else "No"


        return view
    }
}