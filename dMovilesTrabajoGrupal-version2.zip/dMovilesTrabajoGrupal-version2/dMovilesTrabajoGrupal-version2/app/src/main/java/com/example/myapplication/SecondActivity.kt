package com.example.myapplication

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity() {

    private lateinit var vehiculoAdapter: ArrayAdapter<Vehiculo>
    private val vehiculos = mutableListOf<Vehiculo>() // Lista mutable para los vehículos

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Cargar el diseño de la segunda pantalla
        setContentView(R.layout.activity_dos)

        // Inicializar la lista de vehículos
//        vehiculos = mutableListOf(
//            Vehiculo(R.drawable.ic_vehicle, "ABC123", "Toyota", "2020", "Blanco", 20000.0, true),
//            Vehiculo(R.drawable.ic_vehicle, "XYZ789", "Honda", "2018", "Negro", 15000.0, false)
//        )

        // Configurar el adaptador para la lista
        vehiculoAdapter = VehiculoAdapter(this, vehiculos)
        val listView = findViewById<ListView>(R.id.listView)
        listView.adapter = vehiculoAdapter

        // Configurar el botón para abrir el formulario
        val btnAgregarVehiculo = findViewById<Button>(R.id.btnAgregarVehiculo)
        btnAgregarVehiculo.setOnClickListener {
            val intent = Intent(this, FormularioVehiculoActivity::class.java)
            startActivityForResult(intent, 1)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == 1) {
            val nuevoVehiculo = data?.getSerializableExtra("vehiculo") as Vehiculo
            if (nuevoVehiculo != null) {
                vehiculos.add(nuevoVehiculo) // Agrega el nuevo vehículo
                vehiculoAdapter.notifyDataSetChanged() // Actualiza el adaptador
            }
        }
    }
}